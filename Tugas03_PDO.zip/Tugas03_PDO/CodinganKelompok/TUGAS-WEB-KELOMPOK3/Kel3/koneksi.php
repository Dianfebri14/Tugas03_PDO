<?php 
	
	$db = new PDO('mysql:host=localhost;dbname=phbweb2_tugas03_pdo', 'root', '');
